package pindorama.utils.enums;

public enum UserType {
    USER, MODERATOR, ADM
}