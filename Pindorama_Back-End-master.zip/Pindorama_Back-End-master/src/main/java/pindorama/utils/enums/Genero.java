package pindorama.utils.enums;

public enum Genero {
    M, F, O
}